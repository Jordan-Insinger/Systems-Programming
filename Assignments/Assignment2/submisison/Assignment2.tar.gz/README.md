Compilation Instructions: 
    make - will execute "gcc -o magic_transformer src/magic_transformer.c"
    make clean - will remove executable "rm -f magic_transformer"

Example CLI Arguments:
    ./magic_transformer <testcases/case5/input.txt agent_performance:stderr state_rating:stdout
